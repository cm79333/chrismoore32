package com.example.floortilingcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.floortilingcalculator.ui.theme.FloorTilingCalculatorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FloorTilingApp()
        }
    }
}

@Composable
fun FloorTilingApp() {
    var length by remember { mutableStateOf("") }
    var width by remember { mutableStateOf("") }
    var selectedTileSize by remember { mutableStateOf(12) }
    var result by remember { mutableStateOf("Tiles needed: ") }

    Column(
        modifier = Modifier.padding(16.dp)
    ) {
        Text("Floor Tiling Calculator", fontSize = 20.sp)
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = length,
            onValueChange = { length = it },
            label = { Text("Enter Length (feet)") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = width,
            onValueChange = { width = it },
            label = { Text("Enter Width (feet)") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row {
            RadioButton(
                selected = selectedTileSize == 12,
                onClick = { selectedTileSize = 12 }
            )
            Text("12\" x 12\" Tiles")
            Spacer(modifier = Modifier.width(10.dp))
            RadioButton(
                selected = selectedTileSize == 18,
                onClick = { selectedTileSize = 18 }
            )
            Text("18\" x 18\" Tiles")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                val lengthVal = length.toDoubleOrNull() ?: 0.0
                val widthVal = width.toDoubleOrNull() ?: 0.0
                val area = lengthVal * widthVal
                val numTiles = area / ((selectedTileSize / 12.0) * (selectedTileSize / 12.0))
                result = "Tiles needed: ${"%.0f".format(numTiles)}"
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Calculate Tiles")
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(result, fontSize = 18.sp)
    }
}

